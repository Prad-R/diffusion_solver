%%
warning('off', 'all'); global Nx  Ny L H fx fy xn yn; warning('on', 'all');
L = 1;
H = 0.5;
Nx = 100;
Ny = 50;
fx = 0.99;
fy = 0.98;

[xn, yn] = generate_grid();

T_curr = 15*ones(Nx,Ny);
res = [];

for i = 1:100
    T_next = gauss_seidel(T_curr);
    res = [res mean(abs(T_next(:)-T_curr(:)))];
    T_curr = T_next;
end
[Xn,Yn] = meshgrid(xn,yn);
Xn = Xn'
Yn = Yn';
contourf(Xn,Yn,T_curr,30)
axis equal

%%

function T_update = gauss_seidel(T)
    warning('off', 'all'); global Nx  Ny xn yn; warning('on', 'all');
    for i = 1:Nx
        for j = 1:Ny
            [aE,aW,aN,aS,aP,Su] = coeffs(i,j,xn,yn);
            T(i,j) = Su;
            if i<Nx
                T(i,j) = T(i,j) + aE*T(i+1,j);
            end
            if i>1
                T(i,j) = T(i,j) + aW*T(i-1,j);
            end
            if j>1
                T(i,j) = T(i,j) + aS*T(i,j-1);
            end
            if j<Ny
                T(i,j) = T(i,j) + aN*T(i,j+1);
            end
            T(i,j) = T(i,j)/aP;
        end
    end
    T_update = T;
end

function [aE,aW,aN,aS,aP,Su] = coeffs(i,j,xn,yn)
    warning('off', 'all'); global Nx  Ny L H fx fy xn yn; warning('on', 'all');
    if i ~= 1 && i ~= Nx && j ~= 1 && j ~= Ny
        delx = (xn(i+1)-xn(i-1))/(1+fx);
        dely = (yn(j+1)-yn(j-1))/(1+fy);
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        Su = 500000*delx*dely;
        aP = aE+aW+aN+aS+30000*delx*dely;
    elseif j == 1 && i ~= 1 && i ~= Nx
        delx = (xn(i+1)-xn(i-1))/(1+fx);
        dely = 2*yn(1);
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = 0;
        Su = 500000*delx*dely-(15*16/yn(1));
        aP = aE+aW+aN+aS+30000*delx*dely-16/yn(1);
    elseif j == Ny && i ~= 1 && i ~= Nx
        delx = (xn(i+1)-xn(i-1))/(1+fx);
        dely = 2*(H-yn(Ny));
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = 0;
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        Su = 500000*delx*dely+32*10/(H-yn(Ny));
        aP = aE+aW+aN+aS+30000*delx*dely+32/(H-yn(Ny));
    elseif i == 1 && j ~= 1 && j ~= Ny
        delx = 2*xn(1);
        dely = (yn(j+1)-yn(j-1))/(1+fy);
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = 0;
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        Su = 500000*delx*dely;
        aP = aE+aW+aN+aS+30000*delx*dely;
    elseif i == Nx && j ~= 1 && j ~= Ny
        delx = 2*(L-xn(Nx));
        dely = (yn(j+1)-yn(j-1))/(1+fy);
        aE = 0;
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        T4 = 5*(1-yn(j)/H)+15*sin(pi*yn(j)/H);
        Su = 500000*delx*dely+(k_interp(j,"e")*T4/(L-xn(Nx)));
        aP = aE+aW+aN+aS+30000*delx*dely+k_interp(j,"e")/(L-xn(Nx));
    elseif i == 1 && j == 1
        delx = 2*xn(1);
        dely = 2*yn(1);
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = 0;
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = 0;
        Su = 500000*delx*dely-(15*16/yn(1));
        aP = aE+aW+aN+aS+30000*delx*dely-16/yn(1);
    elseif i == 1 && j == Ny
        delx = 2*xn(1);
        dely = 2*(H-yn(Ny));
        aE = k_interp(j,"e")*dely/(xn(i+1)-xn(i));
        aW = 0;
        aN = 0;
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        Su = 500000*delx*dely+32*10/(H-yn(Ny));
        aP = aE+aW+aN+aS+30000*delx*dely+32/(H-yn(Ny));
    elseif i == Nx && j == 1
        delx = 2*(L-xn(Nx));
        dely = 2*yn(1);
        aE = 0;
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = k_interp(j,"n")*delx/(yn(j+1)-yn(j));
        aS = 0;
        T4 = 5*(1-yn(j)/H)+15*sin(pi*yn(j)/H);
        Su = 500000*delx*dely+(k_interp(j,"e")*T4/(L-xn(Nx)))-(15*16/yn(1));
        aP = aE+aW+aN+aS+30000*delx*dely+k_interp(j,"e")/(L-xn(Nx))-16/yn(1);  
    else
        delx = 2*(L-xn(Nx));
        dely = 2*(H-yn(Ny));
        aE = 0;
        aW = k_interp(j,"w")*dely/(xn(i)-xn(i-1));
        aN = 0;
        aS = k_interp(j,"s")*delx/(yn(j)-yn(j-1));
        T4 = 5*(1-yn(j)/H)+15*sin(pi*yn(j)/H);
        Su = 500000*delx*dely+(k_interp(j,"e")*T4/(L-xn(Nx)))+32*10/(H-yn(Ny));
        aP = aE+aW+aN+aS+30000*delx*dely+k_interp(j,"e")/(L-xn(Nx))+32/(H-yn(Ny)); 
    end
end
    
function kp = k(y)
    kp = 16*(y/0.5+1);
end

function kd = k_interp(j,dir)
    warning('off', 'all'); global Ny H fy yn; warning('on', 'all');
    if dir == "e" || dir == "w"
        kd = k(yn(j));
    elseif dir == "n"
        if j ~= Ny
            yd = yn(j)*(fy/(1+fy)) + yn(j+1)*(1/(fy+1));
            kd = k(yd);
        else
            kd = k(H);
        end
    else
        if j ~= 1
            yd = yn(j-1)*(fy/(1+fy)) + yn(j)*(1/(fy+1));
            kd = k(yd);
        else
            kd = k(0);
        end
    end
end

function [nodes_x,nodes_y] = generate_grid()
    warning('off', 'all'); global L H Nx  Ny  fx fy; warning('on', 'all');
    x = stretch(L,Nx,fx);
    y = stretch(H,Ny,fy);
    nodes_x = [];
    nodes_y = [];
    for i =1:Nx
        mid = 0.5*(x(i) + x(i+1));
        nodes_x = [nodes_x mid];
    end
    for i = 1:Ny
        mid = 0.5*(y(i) + y(i+1));
        nodes_y = [nodes_y mid];
    end
end

function coords = stretch(L,N,f)
    coords = [0 1];
    for i = 3:N+1
       coords(i) = coords(i-1) + f*(coords(i-1)-coords(i-2));
    end
    coords = L*coords./max(coords);
end